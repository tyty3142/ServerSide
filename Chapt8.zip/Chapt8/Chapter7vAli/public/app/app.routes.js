System.register([], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var AppRoutes;
    return {
        setters:[],
        execute: function() {
            exports_1("AppRoutes", AppRoutes = [{
                    path: '**',
                    redirectTo: '/',
                }]);
        }
    }
});
//# sourceMappingURL=app.routes.js.map