// Load the module dependencies
const mongoose = require('mongoos   e');
const Schema = mongoose.Schema;

// Define a new 'ArticleSchema'
const ArticleSchema = new Schema({
    created: {
        type: Date,
        default: Date.now
    },
    firstname: {
        type: String,
        default: '',
        trim: true,
        required: 'First name cannot be blank'
    },
    lastname: {
        type: String,
        default: '',
        trim: true,
        required: 'Last name cannot be blank'
    },
    email: {
        type: String,
        default: '',
        trim:true,
        required: 'Email cannot be blank'
    },
    phone: {
        type: String,
        default: '',
        trim:true
    },
    //enter Program Here,
    //enter Term here,
    info: {
        type: String,
        default: '',
        trim:true
    }
    creator: {
        type: Schema.ObjectId,
        ref: 'User'
    }
});

// Create the 'Article' model out of the 'ArticleSchema'
mongoose.model('Article', ArticleSchema);